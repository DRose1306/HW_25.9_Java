import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int rows = 5;
        int cols = 7;
        char[][] alphabet = new char[rows][cols];
        char letter = 'А';
        for (int i = 0; i < alphabet.length; i++) {
            for (int j = 0; j < alphabet[i].length; j++) {
                alphabet[i][j] = letter;
                letter++;
                if (letter > 'Я') break;
                if (letter == 'Ж') {
                    if (j < alphabet[i].length - 1) j++;
                    else {
                        j = 0;
                        i++;
                    }
                    alphabet[i][j] = 'Ё';
                }
            }
        }
        for (int i = 0; i < alphabet.length; i++) {
            for (int j = 0; j < alphabet[i].length; j++) {
                System.out.print(alphabet[i][j] + " ");

            }
            System.out.println();
        }
    }
}
//No2. Двумерные массивы
//Создайте двумерный массив и заполните его заглавными буквами русского алфавита.
// Буква Ё должна быть на своём месте.

//Добрый день, Урмат!
//Вам нужно
//1 создать переменную-счётчик letter типа char и положить в неё первую букву.
//2 организовать цикл не по буквам, а по массивам (внешнему и внутренним).
//В каждой итерации присваивать значение из letter в элемент массива.
// Затем делать letter++, чтобы получить следующую букву.
//3 Остановить цикл, когда после letter++ буква будет больше 'Я'.
//4 Когда Вы положили Е в массив и сделали letter++,
// то нужно сдвинуть индекс на следующую ячейку и записать в неё Ё.
// Обратите внимание, что индекс нужно сдвинуть на следующий элемент в строке.
// Но если этот элемент является последним, то нужно сдвинуть индекс на левый элемент следующей строки.