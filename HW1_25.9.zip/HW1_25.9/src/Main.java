import java.time.LocalDate;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        LocalDate[] dates = {
                LocalDate.of(1967, 1, 14),
                LocalDate.of(2003, 3, 3),
                LocalDate.of(1967, 5, 11),
                LocalDate.of(1997, 6, 13),
                LocalDate.of(2001, 1, 16),
                LocalDate.of(2012, 5, 28),
                LocalDate.of(2001, 9, 11),
                LocalDate.of(2022, 2, 24),
        };

        System.out.println(Arrays.toString(dates));

        year(dates);
        System.out.println("Отсортированный массив по году: " + Arrays.toString(dates));

        dayOfMonth(dates);
        System.out.println("Отсортированный массив по дню месяца: " + Arrays.toString(dates));
    }
    public static void year(LocalDate[] dates) {
        Arrays.sort(dates, (date1, date2) -> date1.getYear() - date2.getYear());
    }
    public static void dayOfMonth(LocalDate[] dates) {
        Arrays.sort(dates, (date1, date2) -> date1.getDayOfMonth() - date2.getDayOfMonth());
    }
}
//No1. Сортировка
//1 Создайте массив из 8 элементов.
// В массиве должны храниться даты (класс LocalDate).
// Чтобы создать элемент LocalDate используйте метод
// LocalDate.of(год, месяц, день), где год, месяц и день – целые числа.
//Выведите массив в консоль.
//2 Напишите метод, который отсортирует массив дат по году. Выведите массив в консоль.
//3 Напишите метод, который отсортирует массив дат по дню месяца. Выведите массив в консоль.