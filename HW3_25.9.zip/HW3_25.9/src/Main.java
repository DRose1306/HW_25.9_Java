import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();//получаем размер двумерного массива рандомом
        int n = rnd.nextInt(2, 10);//но в ограниченном числовом диапазоне для удобности рассмотрения
        System.out.println("Количество элементов равно " + n);
        int[][] spiral = generateSpiral(n);

        for (int i = 0; i < spiral.length; i++) {
            for (int j = 0; j < spiral.length; j++) {
                System.out.printf("%02d ", spiral[i][j]);
            }
            System.out.println();
        }
    }

    private static int[][] generateSpiral(int n) {
        int[][] spiral = new int[n][n];
        int current = 1;
        int left = 0;
        int right = spiral.length -1;
        int top = 0;
        int bottom = spiral.length -1;

        while (current <= n*n){
            for (int i = left; i <= right; i++) { //отсчет вправо
                spiral[top][i] = current++;
            }
            top++;

            for (int i = top; i <= bottom; i++) { //отсчет вниз
                spiral[i][right] = current++;
            }
            right--;

            for (int i = right; i >= left; i--) { // отсчет влево
                spiral[bottom][i] = current++;
            }
            bottom--;

            for (int i = bottom; i >= top; i--) { //отсчет вверх
                spiral[i][left] = current++;
            }
            left++;
        }
        return spiral;
    }
}
//Пусть в двумерном массиве N элементов.
// Заполните двумерный массив целыми числами от 1 до N по спирали.
// Например,
//01 02 03 04
//12 13 14 05
//11 16 15 06
//10 09 08 07